document.addEventListener('DOMContentLoaded', () => {
    // 1. Language Toggle Logic
    const langBtnRu = document.getElementById('btnLangRu');
    const langBtnTj = document.getElementById('btnLangTj');
    const ruElements = document.querySelectorAll('.lang-ru');
    const tjElements = document.querySelectorAll('.lang-tj');
    const htmlTag = document.documentElement;

    function setLanguage(lang) {
        if (lang === 'tj') {
            htmlTag.setAttribute('lang', 'tg');
            langBtnTj.classList.add('active');
            langBtnRu.classList.remove('active');
            
            ruElements.forEach(el => el.style.display = 'none');
            tjElements.forEach(el => {
                if (el.tagName === 'OPTION') {
                    el.style.display = 'block';
                } else if (el.tagName === 'SPAN' || el.tagName === 'I') {
                    el.style.display = 'inline';
                } else {
                    el.style.display = 'block';
                }
            });
            localStorage.setItem('dandoni_lang', 'tj');
        } else {
            htmlTag.setAttribute('lang', 'ru');
            langBtnRu.classList.add('active');
            langBtnTj.classList.remove('active');
            
            tjElements.forEach(el => el.style.display = 'none');
            ruElements.forEach(el => {
                if (el.tagName === 'OPTION') {
                    el.style.display = 'block';
                } else if (el.tagName === 'SPAN' || el.tagName === 'I') {
                    el.style.display = 'inline';
                } else {
                    el.style.display = 'block';
                }
            });
            localStorage.setItem('dandoni_lang', 'ru');
        }
    }

    langBtnRu.addEventListener('click', () => setLanguage('ru'));
    langBtnTj.addEventListener('click', () => setLanguage('tj'));

    // Restore saved language or default to Russian
    const savedLang = localStorage.getItem('dandoni_lang') || 'ru';
    setLanguage(savedLang);


    // 2. Theme Toggle Logic
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const bodyTag = document.body;

    function setTheme(theme) {
        if (theme === 'light') {
            bodyTag.classList.remove('theme-dark');
            bodyTag.classList.add('theme-light');
            themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            localStorage.setItem('dandoni_theme', 'light');
        } else {
            bodyTag.classList.remove('theme-light');
            bodyTag.classList.add('theme-dark');
            themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            localStorage.setItem('dandoni_theme', 'dark');
        }
    }

    themeToggleBtn.addEventListener('click', () => {
        const currentTheme = bodyTag.classList.contains('theme-dark') ? 'dark' : 'light';
        setTheme(currentTheme === 'dark' ? 'light' : 'dark');
    });

    // Restore saved theme or default to Dark
    const savedTheme = localStorage.getItem('dandoni_theme') || 'dark';
    setTheme(savedTheme);


    // 3. Header Scroll Effect
    const header = document.querySelector('.main-header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });


    // 4. Fallback Modal Trigger
    const bookingModal = document.getElementById('bookingModal');
    const openModalButtons = document.querySelectorAll('.open-modal-btn');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const bookingForm = document.getElementById('bookingForm');
    const successMsg = document.getElementById('successMsg');

    function openModal() {
        bookingModal.classList.add('active');
        bookingForm.style.display = 'flex';
        successMsg.style.display = 'none';
        document.body.style.overflow = 'hidden'; 
    }

    function closeModal() {
        bookingModal.classList.remove('active');
        document.body.style.overflow = '';
    }

    openModalButtons.forEach(btn => {
        btn.addEventListener('click', openModal);
    });

    closeModalBtn.addEventListener('click', closeModal);
    bookingModal.addEventListener('click', (e) => {
        if (e.target === bookingModal) {
            closeModal();
        }
    });

    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        bookingForm.style.opacity = '0';
        setTimeout(() => {
            bookingForm.style.display = 'none';
            successMsg.style.display = 'flex';
            successMsg.style.opacity = '1';
        }, 300);
    });


    // 5. High-End Interactive Inline Appointment Booking Logic
    const doctorCards = document.querySelectorAll('.doctor-card');
    const timeSlots = document.querySelectorAll('.time-slot');
    const dateInput = document.getElementById('bookingDate');
    const mainBookingForm = document.getElementById('mainBookingForm');
    const mainBookingSuccess = document.getElementById('mainBookingSuccess');
    const btnBookAgain = document.getElementById('btnBookAgain');
    
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
    dateInput.value = today;

    // Doctor Selection Cards
    doctorCards.forEach(card => {
        card.addEventListener('click', () => {
            doctorCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
        });
    });

    // Time Slot Selectors
    timeSlots.forEach(slot => {
        slot.addEventListener('click', () => {
            timeSlots.forEach(s => s.classList.remove('active'));
            slot.classList.add('active');
        });
    });

    // Main Booking Form Submission
    mainBookingForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Gather selection values
        const activeDoctorCard = document.querySelector('.doctor-card.active');
        const activeTimeSlot = document.querySelector('.time-slot.active');
        const doctorName = activeDoctorCard ? activeDoctorCard.querySelector('.dr-name').innerText : 'Д-р Алишер';
        const dateValue = dateInput.value;
        const timeSlotValue = activeTimeSlot ? activeTimeSlot.dataset.time : '09:00';
        const patientName = document.getElementById('bookingName').value;
        const patientPhone = document.getElementById('bookingPhone').value;

        // Custom receipt display
        document.getElementById('receiptDoctor').innerText = doctorName;
        
        // Formatted date string (DD.MM.YYYY)
        const dateParts = dateValue.split('-');
        const formattedDate = dateParts.length === 3 ? `${dateParts[2]}.${dateParts[1]}.${dateParts[0]}` : dateValue;
        document.getElementById('receiptDate').innerText = formattedDate;
        
        document.getElementById('receiptTime').innerText = timeSlotValue;
        document.getElementById('receiptName').innerText = patientName;

        // Handoff details logged to console
        console.log(`[Dandoni Solim Appointment booked] Name: ${patientName}, Phone: ${patientPhone}, Doctor: ${doctorName}, Date: ${formattedDate}, Time: ${timeSlotValue}`);

        // Smooth transition to Success Screen
        mainBookingForm.style.opacity = '0';
        setTimeout(() => {
            mainBookingForm.style.display = 'none';
            mainBookingSuccess.style.display = 'flex';
            mainBookingSuccess.style.opacity = '1';
        }, 300);
    });

    // Reset Form to book again
    btnBookAgain.addEventListener('click', () => {
        mainBookingSuccess.style.display = 'none';
        mainBookingForm.style.display = 'flex';
        mainBookingForm.style.opacity = '1';
        
        // Reset name, phone and date to defaults
        document.getElementById('bookingName').value = '';
        document.getElementById('bookingPhone').value = '';
        dateInput.value = today;
    });


    // 6. Mobile Menu Toggle
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const mobileNavOverlay = document.getElementById('mobileNavOverlay');
    const closeMobileMenuBtn = document.getElementById('closeMobileMenuBtn');
    const mobLinks = document.querySelectorAll('.mob-link');

    function openMobileMenu() {
        mobileNavOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeMobileMenu() {
        mobileNavOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    mobileMenuToggle.addEventListener('click', openMobileMenu);
    closeMobileMenuBtn.addEventListener('click', closeMobileMenu);
    
    mobLinks.forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });

    mobileNavOverlay.addEventListener('click', (e) => {
        if (e.target === mobileNavOverlay) {
            closeMobileMenu();
        }
    });
});
